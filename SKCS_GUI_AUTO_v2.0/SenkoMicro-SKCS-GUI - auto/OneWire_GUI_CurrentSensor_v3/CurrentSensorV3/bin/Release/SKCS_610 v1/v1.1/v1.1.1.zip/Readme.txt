v1.1.0
1. add data log
2. cleafy FAIL and PASS

v1.1.1
revert to VS2010, surppoting xp and win7

