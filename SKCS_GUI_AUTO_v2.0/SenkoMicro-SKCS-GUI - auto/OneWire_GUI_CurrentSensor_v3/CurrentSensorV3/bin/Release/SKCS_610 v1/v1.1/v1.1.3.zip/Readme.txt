v1.1.0
1. add data log
2. cleafy FAIL and PASS

v1.1.1
revert to VS2010, surppoting xp and win7

v1.1.2
fix mannual auto change error

v1.1.3
improve trim code precision

